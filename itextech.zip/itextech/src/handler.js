const awsServerlessExpress = require('aws-serverless-express');

const app = require('./appnode');
const binaryMimeTypes = [
    'application/javascript',
    'application/json',
    'application/octet-stream',
    'binary/octet-stream',
    'application/font-sfnt',
    'application/font-woff',
    'application/font-woff2',
    'application/x-font-ttf',
    'application/xml',
    'font/eot',
    'font/ttf',
    'font/woff',
    'font/woff2',
    'font/opentype',
    'font/otf',
    'image/jpeg',
    'image/jpg',
    'image/png',
    'image/svg+xml',
    'image/svg',
    'text/comma-separated-values',
    'text/css',
    'text/html',
    'text/javascript',
    'text/plain',
    'text/text',
    'text/xml',
    'multipart/form-data'
];
const server = awsServerlessExpress.createServer(app,null, binaryMimeTypes);
console.log("UI:HANDLER::"+process.env.REACT_APP_API_HOSTNAME)
console.log("UI:HANDLER::"+process.env.REACT_APP_UI_HOSTNAME)
exports.handler = (event, context) => {
    console.log("UI:HANDLER:ENVIRONMENT VARIABLES::"+JSON.stringify(process.env, null, 2));
    console.log("UI:HANDLER:EVENT::"+JSON.stringify(event, null, 2));
    awsServerlessExpress.proxy(server, event, context);
}
