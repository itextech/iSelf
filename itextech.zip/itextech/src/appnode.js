
'use strict';

const path = require('path');
const cors = require('cors');
const express = require('express');
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
var app = express();
app.use(cors({credentials : true}));
app.use(cookieParser()); // For reading cookies
app.use(bodyParser.urlencoded({ extended : false })); // For reading form post body required for okta tokens
app.use('/', express.static(__dirname +'/build/'));
module.exports = app;
